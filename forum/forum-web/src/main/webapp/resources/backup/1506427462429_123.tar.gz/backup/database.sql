-- MySQL dump 10.13  Distrib 5.7.18, for Win64 (x86_64)
--
-- Host: localhost    Database: xeon_forum
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_answer`
--

DROP TABLE IF EXISTS `t_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `chosen` int(11) NOT NULL,
  `content` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `qname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5F4291E985C5CCC` (`qid`),
  KEY `FK5F4291E9FFFAF8B5` (`uid`),
  CONSTRAINT `FK5F4291E985C5CCC` FOREIGN KEY (`qid`) REFERENCES `t_question` (`id`),
  CONSTRAINT `FK5F4291E9FFFAF8B5` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_answer`
--

LOCK TABLES `t_answer` WRITE;
/*!40000 ALTER TABLE `t_answer` DISABLE KEYS */;
INSERT INTO `t_answer` VALUES (1,'Publisher',1,'sgsfgfsagsfewt','2017-09-01 00:00:00',NULL,1,2),(2,'Publisher',0,'sgsfdfgagsfewt','2017-09-01 00:00:00',NULL,1,2),(3,'Publisher',0,'sgsfgioagsfewt','2017-09-01 00:00:00',NULL,1,2),(4,'Publisher',1,'sgsfgiogsfewt','2017-09-01 00:00:00',NULL,2,2),(5,'Publisher',0,'sgstygsfewt','2017-09-01 00:00:00',NULL,2,2),(6,'Publisher',0,'sgwragsfewt','2017-09-01 00:00:00',NULL,2,2);
/*!40000 ALTER TABLE `t_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_attachment`
--

DROP TABLE IF EXISTS `t_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_attach` int(11) DEFAULT NULL,
  `is_img` int(11) DEFAULT NULL,
  `is_index_pic` int(11) DEFAULT NULL,
  `new_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `old_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) NOT NULL,
  `suffix` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK48549DCEFF1F5864` (`tid`),
  CONSTRAINT `FK48549DCEFF1F5864` FOREIGN KEY (`tid`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attachment`
--

LOCK TABLES `t_attachment` WRITE;
/*!40000 ALTER TABLE `t_attachment` DISABLE KEYS */;
INSERT INTO `t_attachment` VALUES (1,1,0,1,'bb1','aa1',123,'txt','txt',1),(2,0,1,0,'bb2','aa2',123,'doc','doc',2),(3,0,0,1,'bb3','aa3',123,'jpg','jpg',1),(4,0,1,0,'bb4','aa4',123,'txt','txt',3),(5,1,0,1,'bb5','aa5',123,'gif','gif',NULL),(6,1,0,0,'bb6','aa6',123,'ppt','ppt',1),(7,0,1,1,'bb7','aa7',123,'gif','gif',4),(8,1,0,0,'bb8','aa8',123,'ppt','ppt',NULL),(9,0,1,1,'bb9','aa9',123,'jpg','jpg',2),(10,1,0,0,'bb10','aa10',123,'xls','xls',4);
/*!40000 ALTER TABLE `t_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_channel`
--

DROP TABLE IF EXISTS `t_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_link` int(11) DEFAULT NULL,
  `custom_link_url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `is_index` int(11) DEFAULT NULL,
  `is_top_nav` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `nav_order` int(11) DEFAULT NULL,
  `orders` int(11) NOT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE79D70381E0BE7B4` (`pid`),
  CONSTRAINT `FKE79D70381E0BE7B4` FOREIGN KEY (`pid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_channel`
--

LOCK TABLES `t_channel` WRITE;
/*!40000 ALTER TABLE `t_channel` DISABLE KEYS */;
INSERT INTO `t_channel` VALUES (1,0,'#',0,0,'exam sector',NULL,1,0,0,0,NULL),(2,0,'#',0,0,'exam1',NULL,1,0,1,1,1),(3,0,'#',0,0,'exam2',NULL,2,0,1,2,1),(4,0,'#',0,0,'exam3',NULL,3,0,0,1,1),(5,0,'#',0,0,'exam4',NULL,4,0,1,2,1),(6,0,'#',0,0,'article sector',NULL,2,0,0,0,NULL),(7,0,'#',0,0,'article1',NULL,1,0,1,1,6),(8,0,'#',0,0,'article2',NULL,2,0,1,2,6),(9,0,'#',0,0,'article3',NULL,3,0,1,1,6),(10,0,'#',0,0,'article4',NULL,4,0,0,1,6),(11,0,'#',0,0,'assignment sector',NULL,3,0,0,0,NULL),(12,0,'#',0,0,'assignment1',NULL,1,0,0,0,11),(13,0,'#',0,0,'assignment2',NULL,2,0,0,0,11),(14,0,'#',0,0,'assignment3',NULL,3,0,0,0,11),(15,0,'#',0,0,'assignment4',NULL,4,0,0,0,11),(16,0,'#',0,0,'activity sector',NULL,4,0,0,0,NULL),(17,0,'#',0,0,'activity1',NULL,1,0,0,0,16),(18,0,'#',0,0,'activity2',NULL,2,0,0,0,16),(19,0,'#',0,0,'activity3',NULL,3,0,0,0,16),(20,0,'#',0,0,'activity4',NULL,4,0,0,0,16);
/*!40000 ALTER TABLE `t_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_forum_link`
--

DROP TABLE IF EXISTS `t_forum_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_forum_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `new_win` int(11) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `url_class` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `url_id` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_forum_link`
--

LOCK TABLES `t_forum_link` WRITE;
/*!40000 ALTER TABLE `t_forum_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_forum_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group`
--

DROP TABLE IF EXISTS `t_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group`
--

LOCK TABLES `t_group` WRITE;
/*!40000 ALTER TABLE `t_group` DISABLE KEYS */;
INSERT INTO `t_group` VALUES (1,'Responsible for the math department\'s website','Math Department'),(2,'Responsible for the art department\'s website','Art Department'),(3,'Responsible for the sports department\'s website','Sports Department');
/*!40000 ALTER TABLE `t_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group_channel`
--

DROP TABLE IF EXISTS `t_group_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) DEFAULT NULL,
  `g_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB7D322B81E38A8A0` (`c_id`),
  KEY `FKB7D322B8FE980518` (`g_id`),
  CONSTRAINT `FKB7D322B81E38A8A0` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FKB7D322B8FE980518` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group_channel`
--

LOCK TABLES `t_group_channel` WRITE;
/*!40000 ALTER TABLE `t_group_channel` DISABLE KEYS */;
INSERT INTO `t_group_channel` VALUES (1,1,1),(2,2,1),(3,3,1),(4,6,1),(5,8,1),(6,11,2),(7,12,2),(8,13,2),(9,16,2),(10,17,2),(11,18,2),(12,7,3),(13,6,3);
/*!40000 ALTER TABLE `t_group_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_index_pic`
--

DROP TABLE IF EXISTS `t_index_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_index_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `link_type` int(11) DEFAULT NULL,
  `link_url` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `old_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `sub_title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_index_pic`
--

LOCK TABLES `t_index_pic` WRITE;
/*!40000 ALTER TABLE `t_index_pic` DISABLE KEYS */;
INSERT INTO `t_index_pic` VALUES (1,'2017-09-10 20:21:17',1,NULL,'abc',NULL,1,0,NULL,'123'),(2,'2017-09-10 20:45:00',1,'123','abc',NULL,1,0,'','123'),(3,'2017-09-18 09:55:45',1,NULL,'abc',NULL,1,0,NULL,'123'),(4,'2017-09-24 22:46:27',1,NULL,'abc',NULL,1,0,NULL,'123');
/*!40000 ALTER TABLE `t_index_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_keyword`
--

DROP TABLE IF EXISTS `t_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name_full_py` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name_short_py` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `times` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_keyword`
--

LOCK TABLES `t_keyword` WRITE;
/*!40000 ALTER TABLE `t_keyword` DISABLE KEYS */;
INSERT INTO `t_keyword` VALUES (1,'ab','ab','ab',1),(2,'bc','bc','bc',2),(3,'cd','cd','cd',3),(4,'ef','ef','ef',4),(5,'fg','fg','bc',5),(6,'abc','abc','abc',6),(7,'bcd','bcd','bcd',7),(8,'efg','efg','efg',8),(9,'aaa','aaa','aaa',9),(10,'bbb','bbb','bbb',10),(11,'????','zhaoshengzhengce','zszc',1);
/*!40000 ALTER TABLE `t_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_question`
--

DROP TABLE IF EXISTS `t_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `cname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `coins` int(11) NOT NULL,
  `content` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `keyword` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK712EAF511E0BB6E7` (`cid`),
  KEY `FK712EAF51FFFAF8B5` (`uid`),
  CONSTRAINT `FK712EAF511E0BB6E7` FOREIGN KEY (`cid`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FK712EAF51FFFAF8B5` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_question`
--

LOCK TABLES `t_question` WRITE;
/*!40000 ALTER TABLE `t_question` DISABLE KEYS */;
INSERT INTO `t_question` VALUES (1,'Administrator',NULL,50,'sgsfgfsagsfewt','2017-09-01 00:00:00','aa|aaa','2017-09-01 00:00:00',1,1,'how to solve jlk?',7,1),(2,'Administrator',NULL,50,'sgsfgfsagsfewt','2017-09-01 00:00:00','ef','2017-09-01 00:00:00',1,1,'how to solve xgf?',7,1),(3,'Administrator',NULL,50,'sgsfgfsagsfewt','2017-09-01 00:00:00','ef|efg|aaa','2017-09-01 00:00:00',1,1,'how to solve xcv?',7,1),(4,'Publisher',NULL,50,'sgsfgfsagsfewt','2017-09-01 00:00:00','cd','2017-09-01 00:00:00',1,1,'how to solve vb?',8,2),(5,'Publisher',NULL,50,'sgsfgfsagsfewt','2017-09-01 00:00:00','fg','2017-09-01 00:00:00',1,1,'how to solve sfg?',8,2),(6,'Publisher',NULL,50,'sgsfgfsagsfewt','2017-09-01 00:00:00','bc|bbb|aa','2017-09-01 00:00:00',1,1,'how to solve gdf?',8,2);
/*!40000 ALTER TABLE `t_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `role_type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` VALUES (1,'Administrator','ROLE_ADMIN'),(2,'Publisher','ROLE_PUBLISH'),(3,'Auditor','ROLE_AUDIT'),(4,'Member','ROLE_MEMBER');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_topic`
--

DROP TABLE IF EXISTS `t_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `channel_pic_id` int(11) DEFAULT NULL,
  `cname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `content` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `keyword` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `summary` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA10609A41E0BB6E7` (`cid`),
  KEY `FKA10609A4FFFAF8B5` (`uid`),
  CONSTRAINT `FKA10609A41E0BB6E7` FOREIGN KEY (`cid`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FKA10609A4FFFAF8B5` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_topic`
--

LOCK TABLES `t_topic` WRITE;
/*!40000 ALTER TABLE `t_topic` DISABLE KEYS */;
INSERT INTO `t_topic` VALUES (1,'Administrator',1,NULL,'abababab1','2017-09-01 00:00:00','aa|aaa','2017-09-01 00:00:00',1,1,'abababab1','abababab1',7,1),(2,'Administrator',2,NULL,'bcbcbcbc1','2017-09-02 00:00:00','bc|bbb|aa','2017-09-02 00:00:00',1,0,'bcbcbcbc1','bcbcbcbc1',8,1),(3,'Administrator',4,NULL,'cdcdcdcd1','2017-09-03 00:00:00','cd','2017-09-03 00:00:00',0,1,'cdcdcdbbcd1','cdcdcdcd1',8,1),(4,'Publisher',7,NULL,'dededede1','2017-09-04 00:00:00','ef','2017-09-04 00:00:00',1,1,'dededede1','dededede1',7,2),(5,'Publisher',6,NULL,'efefefef1','2017-09-05 00:00:00','ef|efg|aaa','2017-09-05 00:00:00',1,0,'efefefef1','efefefef1',7,2),(6,'Publisher',8,NULL,'fffffff1','2017-09-06 00:00:00','fg','2017-09-06 00:00:00',0,1,'fffffff1','fffffff1',8,2);
/*!40000 ALTER TABLE `t_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coins` int(11) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `phone` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,50,'2017-09-10 00:00:00','admin1@admin.com','admin1','123','110',1,'admin1'),(2,50,'2017-09-10 00:00:00','admin1@admin.com','admin1','123','110',1,'admin2'),(3,50,'2017-09-10 00:00:00','admin1@admin.com','admin1','123','110',1,'admin3'),(4,50,'2017-09-10 00:00:00','admin1@admin.com','admin1','123','110',1,'admin4'),(5,0,'2017-09-26 18:57:30','14234@gm.com','admin','192023a7bbd73250516f069df18b500','04123134098',1,'admin');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_group`
--

DROP TABLE IF EXISTS `t_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `g_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK300645B6FE980518` (`g_id`),
  KEY `FK300645B62FD58A` (`u_id`),
  CONSTRAINT `FK300645B62FD58A` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FK300645B6FE980518` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_group`
--

LOCK TABLES `t_user_group` WRITE;
/*!40000 ALTER TABLE `t_user_group` DISABLE KEYS */;
INSERT INTO `t_user_group` VALUES (1,1,2),(2,2,2),(3,3,2),(4,1,3),(5,3,3),(6,2,4),(7,1,5),(8,2,5),(9,3,5);
/*!40000 ALTER TABLE `t_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK331DEE5F2D0D18` (`r_id`),
  KEY `FK331DEE5F2FD58A` (`u_id`),
  CONSTRAINT `FK331DEE5F2D0D18` FOREIGN KEY (`r_id`) REFERENCES `t_role` (`id`),
  CONSTRAINT `FK331DEE5F2FD58A` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
INSERT INTO `t_user_role` VALUES (1,1,1),(2,2,2),(3,3,2),(4,2,3),(5,4,4),(6,1,5),(7,2,5),(8,3,5),(9,4,5);
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-26 21:34:21
